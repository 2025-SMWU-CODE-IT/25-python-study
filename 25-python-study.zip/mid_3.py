#2516083 김다은
#중간프로젝트 #3번



#윤년인지 판단하는 함수, if문들을 사용하여 윤년이기위해 만족해야하는 조건들을 충족시키는지 판단.
def IsLeapYear(year):
    if year % 4 == 0: 
        if year % 100 == 0:
            if year % 400 == 0:
                return True #year 값이 4, 100, 400 모두로 나누어떨어지면 윤년이다.
            return False #year 값이 4, 100으로 나누어떨어지나 400으로는 나누어떨어지지 않으면 윤년이 아니다.
        return True #year 값이 4로 나누어떨어지나 100으로는 나누어떨어지지 않으면 윤년이다.

      
    
#입력받은 월의 날짜 수를 리턴하는 함수.
def GetDayOfMonth(month, year):
    if month in [1, 3, 5, 7, 8, 10, 12]:
        return 31
    elif month in [4, 6, 9, 11]:
        return 30
    elif month == 2:
        if IsLeapYear(year):
            return 29
        else: 
            return 28
    return "잘못 입력하였습니다. 1에서 12까지의 값 중 하나를 입력하여 주십시오."   #입력받은 값이 1에서 12까지의 값이 아니라면 오류 메세지를 출력함.



# while True루프를 사용하여 -1이 입력되는 경우에는 루프를 빠져나가 프로그램을 종료하고 아닌 경우에는 값을 계속 입력받을 수 있도록 함.
while True:
    inputyear = int(input("연도를 입력하세요."))
    if inputyear == -1:
        break
    inputmonth = int(input("월을 입력하세요."))

    print(GetDayOfMonth(inputmonth, inputyear))
 