#2516083 김다은
#중간프로젝트 #1번

while True:
    number = int(input("정수를 입력하세요"))
    if number == -1:
        break

    if number<=1:
        print("잘못 입력하였습니다. 2이상의 값을 입력하여 주십시오.")

    def IsPrime(num):
        if num in [2,3, 5]:
            return True
        


    print (IsPrime(number))
        
        

